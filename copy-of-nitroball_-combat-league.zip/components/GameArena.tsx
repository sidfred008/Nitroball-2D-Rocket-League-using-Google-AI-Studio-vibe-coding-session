
import React, { useRef, useEffect, useState } from 'react';
import { Car } from '../types';

interface GameArenaProps {
  userSquad: Car[];
  onMatchEnd: (scoreBlue: number, scoreOrange: number) => void;
}

// --- Game Constants & Types ---
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const GOAL_SIZE = 180;

interface Vector { x: number; y: number; }
interface Entity {
  id: string;
  pos: Vector;
  vel: Vector;
  radius: number;
  color: string;
  team: 'BLUE' | 'ORANGE';
  type: 'PLAYER' | 'BOT' | 'BALL';
  stats?: { speed: number; handling: number; armor: number };
}

export const GameArena: React.FC<GameArenaProps> = ({ userSquad, onMatchEnd }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'PLAYING' | 'GOAL' | 'FINISHED'>('PLAYING');
  const [scores, setScores] = useState({ blue: 0, orange: 0 });
  const [timeLeft, setTimeLeft] = useState(180); // 3 minutes
  const [mousePos, setMousePos] = useState<Vector>({ x: 0, y: 0 });

  // Refs for game loop state to avoid closure staleness
  const entitiesRef = useRef<Entity[]>([]);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const scoreRef = useRef({ blue: 0, orange: 0 });
  const requestIdRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  // --- Initialization ---
  useEffect(() => {
    if (!userSquad || userSquad.length < 1) return;

    // Normalize stats helper
    const getNormStats = (c: Car) => ({
      speed: c.stats.speed / 100,
      handling: c.stats.handling / 100,
      armor: c.stats.armor / 100,
    });

    // 1. Create Ball
    const ball: Entity = {
      id: 'ball',
      pos: { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT / 2 },
      vel: { x: 0, y: 0 },
      radius: 14,
      color: '#ffffff',
      team: 'BLUE', // Neutral
      type: 'BALL',
    };

    // 2. Create Player (First car in squad)
    const playerCar = userSquad[0];
    const player: Entity = {
      id: 'player',
      pos: { x: 100, y: CANVAS_HEIGHT / 2 },
      vel: { x: 0, y: 0 },
      radius: 18,
      color: playerCar.color,
      team: 'BLUE',
      type: 'PLAYER',
      stats: getNormStats(playerCar),
    };

    // 3. Create Teammates (Remaining squad)
    const teammates = userSquad.slice(1).map((car, idx) => ({
      id: `mate-${idx}`,
      pos: { x: 100, y: CANVAS_HEIGHT / 3 * (idx === 0 ? 1 : 2) },
      vel: { x: 0, y: 0 },
      radius: 18,
      color: car.color,
      team: 'BLUE' as const,
      type: 'BOT' as const,
      stats: getNormStats(car),
    }));

    // 4. Create Enemies (Abyssal Lords)
    const enemies = Array.from({ length: 3 }).map((_, idx) => ({
      id: `enemy-${idx}`,
      pos: { x: CANVAS_WIDTH - 100, y: (CANVAS_HEIGHT / 4) * (idx + 1) },
      vel: { x: 0, y: 0 },
      radius: 18,
      color: '#ff4500', // Hell orange
      team: 'ORANGE' as const,
      type: 'BOT' as const,
      stats: { speed: 0.7, handling: 0.7, armor: 0.8 }, 
    }));

    entitiesRef.current = [ball, player, ...teammates, ...enemies];

    // Input Listeners
    const handleKeyDown = (e: KeyboardEvent) => { 
        keysRef.current[e.key.toLowerCase()] = true; 
        if(['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(e.key.toLowerCase())) {
            e.preventDefault();
        }
    };
    const handleKeyUp = (e: KeyboardEvent) => { 
        keysRef.current[e.key.toLowerCase()] = false; 
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Start Loop
    requestIdRef.current = requestAnimationFrame(gameLoop);
    
    // Timer
    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState('FINISHED');
          onMatchEnd(scoreRef.current.blue, scoreRef.current.orange);
          clearInterval(timerInterval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(requestIdRef.current);
      clearInterval(timerInterval);
    };
  }, []);

  // --- Physics Helpers ---
  const dist = (v1: Vector, v2: Vector) => Math.sqrt(Math.pow(v2.x - v1.x, 2) + Math.pow(v2.y - v1.y, 2));
  const normalize = (v: Vector) => {
    const m = Math.sqrt(v.x * v.x + v.y * v.y);
    return m === 0 ? { x: 0, y: 0 } : { x: v.x / m, y: v.y / m };
  };

   // --- Mouse/Pass Interaction ---
   const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
      setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    }
  };

  const handleMouseClick = (e: React.MouseEvent) => {
    const ents = entitiesRef.current;
    const player = ents.find(e => e.type === 'PLAYER');
    const ball = ents.find(e => e.type === 'BALL');
    
    if (!player || !ball) return;

    // Pass Logic: Player must be close to ball to pass
    const distToBall = dist(player.pos, ball.pos);
    if (distToBall > 60) return; // "Dribbling" range

    // Check if clicked on a teammate
    const target = ents.find(ent => 
      ent.type === 'BOT' && 
      ent.team === 'BLUE' && 
      dist(ent.pos, mousePos) < ent.radius + 20
    );

    if (target) {
        // PASS!
        const dx = target.pos.x - ball.pos.x;
        const dy = target.pos.y - ball.pos.y;
        const m = Math.sqrt(dx*dx + dy*dy);
        
        // Set ball velocity towards target, fast
        ball.vel.x = (dx/m) * 30;
        ball.vel.y = (dy/m) * 30;
    }
  };

  // --- Game Loop ---
  const gameLoop = (time: number) => {
    const dt = Math.min((time - lastTimeRef.current) / 1000, 0.1); // Cap dt
    lastTimeRef.current = time;

    update(dt);
    draw();

    if (timeLeft > 0) {
      requestIdRef.current = requestAnimationFrame(gameLoop);
    }
  };

  const update = (dt: number) => {
    const entities = entitiesRef.current;
    const ball = entities.find(e => e.type === 'BALL')!;
    
    // 1. Update Entities
    entities.forEach(e => {
      // --- Player Control ---
      if (e.type === 'PLAYER') {
        const speed = 6 * (e.stats?.speed || 0.5) + 4; // Base speed
        const acc = { x: 0, y: 0 };
        
        if (keysRef.current['arrowup'] || keysRef.current['w']) acc.y -= 1;
        if (keysRef.current['arrowdown'] || keysRef.current['s']) acc.y += 1;
        if (keysRef.current['arrowleft'] || keysRef.current['a']) acc.x -= 1;
        if (keysRef.current['arrowright'] || keysRef.current['d']) acc.x += 1;
        
        if (acc.x !== 0 || acc.y !== 0) {
          const dir = normalize(acc);
          e.vel.x += dir.x * speed * 0.8; // Responsive acceleration
          e.vel.y += dir.y * speed * 0.8;
        }
      } 
      // --- Bot Logic ---
      else if (e.type === 'BOT') {
        const speed = 5 * (e.stats?.speed || 0.5) + 3;
        // Chase ball
        const dx = ball.pos.x - e.pos.x;
        const dy = ball.pos.y - e.pos.y;
        const d = Math.sqrt(dx*dx + dy*dy);
        
        // Simple AI: Move to ball
        if (d > 15) {
           const dir = normalize({ x: dx, y: dy });
           e.vel.x += dir.x * speed * 0.4;
           e.vel.y += dir.y * speed * 0.4;
        }
      }

      // Friction
      const friction = e.type === 'BALL' ? 0.98 : 0.92;
      e.vel.x *= friction;
      e.vel.y *= friction;

      // Cap Velocity
      const maxSpeed = e.type === 'BALL' ? 35 : 12;
      const currSpeed = Math.sqrt(e.vel.x ** 2 + e.vel.y ** 2);
      if (currSpeed > maxSpeed) {
        e.vel.x = (e.vel.x / currSpeed) * maxSpeed;
        e.vel.y = (e.vel.y / currSpeed) * maxSpeed;
      }

      // Apply Velocity
      e.pos.x += e.vel.x;
      e.pos.y += e.vel.y;

      // --- Wall Collisions ---
      // Top/Bottom
      if (e.pos.y - e.radius < 0) { e.pos.y = e.radius; e.vel.y *= -0.8; }
      if (e.pos.y + e.radius > CANVAS_HEIGHT) { e.pos.y = CANVAS_HEIGHT - e.radius; e.vel.y *= -0.8; }
      
      // Left/Right (Check for Goals)
      if (e.pos.x - e.radius < 0) {
        if (e.type === 'BALL' && e.pos.y > (CANVAS_HEIGHT - GOAL_SIZE)/2 && e.pos.y < (CANVAS_HEIGHT + GOAL_SIZE)/2) {
           handleGoal('ORANGE');
        } else {
           e.pos.x = e.radius; e.vel.x *= -0.8;
        }
      }
      if (e.pos.x + e.radius > CANVAS_WIDTH) {
        if (e.type === 'BALL' && e.pos.y > (CANVAS_HEIGHT - GOAL_SIZE)/2 && e.pos.y < (CANVAS_HEIGHT + GOAL_SIZE)/2) {
           handleGoal('BLUE');
        } else {
           e.pos.x = CANVAS_WIDTH - e.radius; e.vel.x *= -0.8;
        }
      }

      // --- Entity vs Entity Collisions ---
      entities.forEach(other => {
        if (e === other) return;

        const d = dist(e.pos, other.pos);
        const minDist = e.radius + other.radius;
        
        if (d < minDist) {
          // Simple elastic collision approximation
          const nx = (other.pos.x - e.pos.x) / d;
          const ny = (other.pos.y - e.pos.y) / d;
          
          // Mass calculation (Ball is light, Cars are heavy)
          const m1 = e.type === 'BALL' ? 1 : 5;
          const m2 = other.type === 'BALL' ? 1 : 5;
          
          const p = 2 * (e.vel.x * nx + e.vel.y * ny - other.vel.x * nx - other.vel.y * ny) / (m1 + m2);

          // Bounciness
          const bounce = (e.type === 'BALL' || other.type === 'BALL') ? 1.5 : 0.5;

          e.vel.x -= p * m2 * nx * bounce;
          e.vel.y -= p * m2 * ny * bounce;
          other.vel.x += p * m1 * nx * bounce;
          other.vel.y += p * m1 * ny * bounce;

          // Separate to prevent sticking
          const overlap = (minDist - d) / 2;
          e.pos.x -= overlap * nx;
          e.pos.y -= overlap * ny;
          other.pos.x += overlap * nx;
          other.pos.y += overlap * ny;
        }
      });
    });
  };

  const handleGoal = (teamScored: 'BLUE' | 'ORANGE') => {
     if (teamScored === 'BLUE') scoreRef.current.blue += 1;
     else scoreRef.current.orange += 1;
     
     setScores({ ...scoreRef.current });
     setGameState('GOAL');
     
     // Reset positions after delay
     setTimeout(() => {
         resetPositions();
         setGameState('PLAYING');
     }, 2000);
  };

  const resetPositions = () => {
      const ents = entitiesRef.current;
      const ball = ents.find(e => e.type === 'BALL');
      if(ball) {
          ball.pos = { x: CANVAS_WIDTH/2, y: CANVAS_HEIGHT/2 };
          ball.vel = { x: 0, y: 0 };
      }
      ents.forEach(e => {
          if (e.type === 'PLAYER' || e.type === 'BOT') {
              e.vel = { x: 0, y: 0 };
              if (e.team === 'BLUE') {
                  e.pos.x = 100;
                  e.pos.y = Math.random() * (CANVAS_HEIGHT - 100) + 50;
              } else {
                  e.pos.x = CANVAS_WIDTH - 100;
                  e.pos.y = Math.random() * (CANVAS_HEIGHT - 100) + 50;
              }
          }
      });
  };

  // --- Rendering ---
  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.fillStyle = '#1a0505'; // Dark Hell Red
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw Grid / Arena Floor
    ctx.strokeStyle = '#4a1a1a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let x = 0; x <= CANVAS_WIDTH; x += 50) { ctx.moveTo(x, 0); ctx.lineTo(x, CANVAS_HEIGHT); }
    for (let y = 0; y <= CANVAS_HEIGHT; y += 50) { ctx.moveTo(0, y); ctx.lineTo(CANVAS_WIDTH, y); }
    ctx.stroke();

    // Draw Center Circle
    ctx.beginPath();
    ctx.arc(CANVAS_WIDTH/2, CANVAS_HEIGHT/2, 80, 0, Math.PI * 2);
    ctx.strokeStyle = '#ff4500';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Draw Goals
    ctx.fillStyle = '#00f3ff'; // Blue Goal
    ctx.fillRect(0, (CANVAS_HEIGHT - GOAL_SIZE)/2, 10, GOAL_SIZE);
    ctx.fillStyle = '#ff4500'; // Orange Goal
    ctx.fillRect(CANVAS_WIDTH - 10, (CANVAS_HEIGHT - GOAL_SIZE)/2, 10, GOAL_SIZE);

    // Draw Entities
    entitiesRef.current.forEach(e => {
        ctx.save();
        ctx.translate(e.pos.x, e.pos.y);

        if (e.type === 'BALL') {
            ctx.fillStyle = '#ffffff';
            ctx.shadowColor = '#ffffff';
            ctx.shadowBlur = 20;
            ctx.beginPath();
            ctx.arc(0, 0, e.radius, 0, Math.PI*2);
            ctx.fill();
        } else {
            // Cars
            ctx.rotate(Math.atan2(e.vel.y, e.vel.x));
            
            // Body
            ctx.fillStyle = e.color;
            ctx.fillRect(-e.radius, -e.radius/2, e.radius*2, e.radius);
            
            // Roof indicator (to show direction)
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.fillRect(0, -e.radius/2 + 2, e.radius - 2, e.radius - 4);
            
            // ID/Name overhead
            if (e.type === 'PLAYER') {
                ctx.rotate(-Math.atan2(e.vel.y, e.vel.x)); // Reset rotation for text
                ctx.fillStyle = '#00f3ff';
                ctx.font = '10px monospace';
                ctx.fillText("YOU", -10, -20);
                // Selection ring
                ctx.strokeStyle = '#00f3ff';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(0, 0, e.radius + 5, 0, Math.PI*2);
                ctx.stroke();
            }
        }
        ctx.restore();
    });

    // --- Pass Target Highlight ---
    const player = entitiesRef.current.find(e => e.type === 'PLAYER');
    const ball = entitiesRef.current.find(e => e.type === 'BALL');
    if (player && ball && dist(player.pos, ball.pos) <= 60) {
       const hoveredTeammate = entitiesRef.current.find(ent => 
         ent.type === 'BOT' && 
         ent.team === 'BLUE' && 
         dist(ent.pos, mousePos) < ent.radius + 20
       );
       if (hoveredTeammate) {
         ctx.save();
         ctx.translate(hoveredTeammate.pos.x, hoveredTeammate.pos.y);
         ctx.strokeStyle = '#00ff00';
         ctx.lineWidth = 2;
         ctx.setLineDash([5, 5]);
         ctx.beginPath();
         ctx.arc(0, 0, hoveredTeammate.radius + 12, 0, Math.PI*2);
         ctx.stroke();
         ctx.fillStyle = '#00ff00';
         ctx.font = 'bold 12px monospace';
         ctx.textAlign = 'center';
         ctx.fillText("CLICK TO PASS", 0, -25);
         ctx.restore();
         canvas.style.cursor = 'pointer';
       } else {
         canvas.style.cursor = 'default';
       }
    } else {
       canvas.style.cursor = 'default';
    }

    // UI Overlays (Goal Text)
    if (gameState === 'GOAL') {
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 60px monospace';
        ctx.textAlign = 'center';
        ctx.fillText("GOAL!", CANVAS_WIDTH/2, CANVAS_HEIGHT/2);
    }
  };

  return (
    <div className="relative flex flex-col items-center">
        <div className="flex justify-between w-[800px] bg-gray-900 p-2 text-white font-mono text-xl border border-gray-700 rounded-t">
            <span className="text-neon-blue w-20 text-center">{scores.blue}</span>
            <span className="text-sm text-gray-400 pt-1">
                {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
            </span>
            <span className="text-hell-orange w-20 text-center">{scores.orange}</span>
        </div>
        <canvas 
            ref={canvasRef} 
            width={CANVAS_WIDTH} 
            height={CANVAS_HEIGHT}
            onMouseMove={handleMouseMove}
            onClick={handleMouseClick}
            className="border-2 border-hell-red bg-black shadow-[0_0_30px_rgba(255,69,0,0.2)]"
        />
        <div className="w-[800px] mt-2 text-xs text-gray-500 flex justify-between uppercase tracking-widest">
            <span>Controls: [ARROWS / WASD] Drive • [CLICK TEAMMATE] Pass Ball</span>
            <span>Pass enabled when near ball</span>
        </div>
    </div>
  );
};
