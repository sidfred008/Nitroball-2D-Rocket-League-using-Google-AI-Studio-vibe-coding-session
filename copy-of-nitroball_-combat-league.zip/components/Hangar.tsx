
import React, { useState } from 'react';
import { Car, CarClass, CLASS_INFO } from '../types';
import { generateCarDesign } from '../services/geminiService';
import { ProgressBar } from './ui/ProgressBar';

interface HangarProps {
  myGarage: Car[];
  addToGarage: (car: Car) => void;
}

export const Hangar: React.FC<HangarProps> = ({ myGarage, addToGarage }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedClass, setSelectedClass] = useState<CarClass>(CarClass.STRIKER);
  const [stylePrompt, setStylePrompt] = useState('Cyberpunk Rusty');
  const [generatedCar, setGeneratedCar] = useState<Car | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setGeneratedCar(null);
    try {
      const partialCar = await generateCarDesign(selectedClass, stylePrompt);
      // Type assertion since we know the service returns a compatible shape mostly
      if (partialCar) {
          setGeneratedCar(partialCar as Car);
      }
    } catch (e) {
      console.error(e);
      alert("Failed to manufacture vehicle. Comms link down.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (generatedCar) {
      addToGarage(generatedCar);
      setGeneratedCar(null);
    }
  };

  const currentClassInfo = CLASS_INFO[selectedClass];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
      {/* Controls */}
      <div className="lg:col-span-4 flex flex-col gap-6 bg-neon-panel p-6 rounded-xl border border-gray-800">
        <h2 className="text-2xl font-bold text-neon-orange uppercase tracking-widest mb-4 border-b border-gray-700 pb-2">
          Vehicle Fabricator
        </h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-xs text-neon-blue mb-2 uppercase">Chassis Class</label>
            <div className="grid grid-cols-3 gap-2">
              {Object.values(CarClass).map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedClass(c)}
                  className={`p-2 text-xs font-bold uppercase rounded border transition-all ${
                    selectedClass === c 
                      ? 'bg-neon-blue/20 border-neon-blue text-white' 
                      : 'bg-gray-900 border-gray-700 text-gray-500 hover:border-gray-500'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Class Info Card */}
          <div className="bg-gray-900/50 p-4 rounded border border-gray-800">
             <h4 className="text-white font-bold text-sm uppercase mb-1">{selectedClass} Class</h4>
             <p className="text-gray-400 text-xs mb-3 leading-relaxed">{currentClassInfo.description}</p>
             <div className="flex justify-between text-xs mb-2">
                 <span className="text-neon-green">High: {currentClassInfo.strengths}</span>
             </div>
             <div className="flex justify-between text-xs mb-2">
                 <span className="text-red-400">Low: {currentClassInfo.weakness}</span>
             </div>
             <div className="space-y-1 mt-3 opacity-70">
                 <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-gray-500">
                    <div className="w-12">Speed</div>
                    <div className="flex-1 h-1 bg-gray-800 rounded overflow-hidden">
                        <div className="h-full bg-cyan-400" style={{width: `${currentClassInfo.stats.speed}%`}}></div>
                    </div>
                 </div>
                 <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-gray-500">
                    <div className="w-12">Armor</div>
                    <div className="flex-1 h-1 bg-gray-800 rounded overflow-hidden">
                        <div className="h-full bg-yellow-400" style={{width: `${currentClassInfo.stats.armor}%`}}></div>
                    </div>
                 </div>
                 <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-gray-500">
                    <div className="w-12">Power</div>
                    <div className="flex-1 h-1 bg-gray-800 rounded overflow-hidden">
                        <div className="h-full bg-red-500" style={{width: `${currentClassInfo.stats.firepower}%`}}></div>
                    </div>
                 </div>
             </div>
          </div>

          <div>
            <label className="block text-xs text-neon-blue mb-2 uppercase">Visual Style</label>
            <input 
              type="text" 
              value={stylePrompt}
              onChange={(e) => setStylePrompt(e.target.value)}
              className="w-full bg-gray-900 border border-gray-700 p-3 rounded text-white focus:border-neon-orange focus:outline-none"
              placeholder="e.g. Stealth, Mad Max, Tron..."
            />
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-4 mt-4 font-bold text-black uppercase tracking-wider rounded transition-all ${
              isGenerating 
                ? 'bg-gray-600 cursor-wait' 
                : 'bg-neon-green hover:bg-green-400 hover:shadow-[0_0_15px_rgba(0,255,157,0.5)]'
            }`}
          >
            {isGenerating ? 'Fabricating...' : 'Initialize Build'}
          </button>
        </div>
        
        {/* Garage List Mini View */}
        <div className="mt-8">
             <h3 className="text-sm text-gray-400 uppercase mb-2">Active Fleet ({myGarage.length})</h3>
             <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                {myGarage.map(car => (
                    <div key={car.id} className="flex justify-between items-center bg-gray-900 p-3 rounded border-l-2 border-neon-blue">
                        <span className="font-mono text-sm">{car.name}</span>
                        <span className="text-xs text-gray-500">{car.class}</span>
                    </div>
                ))}
                {myGarage.length === 0 && <p className="text-gray-600 text-xs italic">No vehicles in garage.</p>}
             </div>
        </div>
      </div>

      {/* Display Area */}
      <div className="lg:col-span-8 flex flex-col justify-center items-center relative min-h-[500px] bg-gradient-to-b from-gray-900 to-black rounded-xl border border-gray-800 p-8">
        
        {/* Background Grid Decoration */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" 
             style={{ 
               backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', 
               backgroundSize: '40px 40px' 
             }} 
        />

        {generatedCar ? (
          <div className="relative z-10 w-full max-w-2xl bg-gray-900/90 backdrop-blur-md border border-neon-blue/30 p-6 rounded-lg shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h2 className="text-3xl font-black italic text-white tracking-tighter">{generatedCar.name}</h2>
                    <span className="inline-block px-2 py-1 bg-neon-orange text-black text-xs font-bold uppercase mt-1 rounded-sm">
                        {generatedCar.class} // {generatedCar.weaponType}
                    </span>
                </div>
                <div className="w-16 h-16 rounded-full" style={{ backgroundColor: generatedCar.color, boxShadow: `0 0 20px ${generatedCar.color}` }}></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-1">
                    <ProgressBar label="Speed" value={generatedCar.stats.speed} colorClass="bg-cyan-400" />
                    <ProgressBar label="Armor" value={generatedCar.stats.armor} colorClass="bg-yellow-400" />
                    <ProgressBar label="Firepower" value={generatedCar.stats.firepower} colorClass="bg-red-500" />
                    <ProgressBar label="Handling" value={generatedCar.stats.handling} colorClass="bg-purple-400" />
                </div>
                <div className="flex flex-col justify-between">
                    <div>
                        <h4 className="text-neon-blue text-xs uppercase mb-1">Special Ability</h4>
                        <p className="text-white font-bold mb-4">{generatedCar.specialAbility}</p>
                        <h4 className="text-gray-500 text-xs uppercase mb-1">System Log</h4>
                        <p className="text-gray-300 text-sm leading-relaxed">{generatedCar.description}</p>
                    </div>
                    <button 
                        onClick={handleSave}
                        className="mt-6 w-full py-3 border border-neon-green text-neon-green font-bold uppercase tracking-wider hover:bg-neon-green hover:text-black transition-colors"
                    >
                        Add to Garage
                    </button>
                </div>
            </div>
          </div>
        ) : (
          <div className="text-center z-10 opacity-50">
             <div className="text-6xl mb-4 animate-pulse">🏎️</div>
             <p className="text-xl font-light uppercase tracking-widest">Awaiting Blueprint Generation...</p>
          </div>
        )}
      </div>
    </div>
  );
};
