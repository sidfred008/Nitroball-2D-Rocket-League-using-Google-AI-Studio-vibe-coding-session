import React from 'react';

interface ProgressBarProps {
  value: number;
  max?: number;
  label: string;
  colorClass?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ value, max = 100, label, colorClass = "bg-neon-blue" }) => {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));
  
  return (
    <div className="w-full mb-2">
      <div className="flex justify-between text-xs uppercase tracking-widest text-gray-400 mb-1">
        <span>{label}</span>
        <span>{value} / {max}</span>
      </div>
      <div className="h-2 w-full bg-gray-800 rounded-full overflow-hidden border border-gray-700">
        <div 
          className={`h-full ${colorClass} transition-all duration-1000 ease-out`} 
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};