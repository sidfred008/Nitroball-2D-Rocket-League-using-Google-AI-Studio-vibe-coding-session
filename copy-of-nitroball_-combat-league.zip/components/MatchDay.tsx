
import React, { useState, useEffect, useRef } from 'react';
import { Car, MatchSimulationResult, MatchEvent } from '../types';
import { simulateMatch } from '../services/geminiService';
import { GameArena } from './GameArena';

interface MatchDayProps {
  roster: Car[];
}

export const MatchDay: React.FC<MatchDayProps> = ({ roster }) => {
  const [simulation, setSimulation] = useState<MatchSimulationResult | null>(null);
  const [currentEventIndex, setCurrentEventIndex] = useState(-1);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false); // New state for game mode
  const [selectedCarIds, setSelectedCarIds] = useState<Set<string>>(new Set());
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto-select first 3 if nothing selected initially
  useEffect(() => {
    if (selectedCarIds.size === 0 && roster.length > 0) {
      const initial = new Set<string>();
      roster.slice(0, 3).forEach(c => initial.add(c.id));
      setSelectedCarIds(initial);
    }
  }, [roster]);

  const toggleCarSelection = (id: string) => {
    if (isSimulating || isPlaying) return;
    const newSet = new Set(selectedCarIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      if (newSet.size < 3) {
        newSet.add(id);
      }
    }
    setSelectedCarIds(newSet);
  };

  const selectedTeam = roster.filter(c => selectedCarIds.has(c.id));

  const runSimulation = async () => {
    if (selectedTeam.length === 0) return;
    setIsSimulating(true);
    setIsPlaying(false);
    setSimulation(null);
    setCurrentEventIndex(-1);
    
    try {
      const result = await simulateMatch(selectedTeam);
      setSimulation(result);
      // Start playing back events
      setCurrentEventIndex(0);
    } catch (error) {
      alert("Match simulation failed. Uplink severed.");
    } finally {
      setIsSimulating(false);
    }
  };

  const enterArena = () => {
    if (selectedTeam.length === 0) return;
    setIsPlaying(true);
    setSimulation(null); // Clear old text sims
  };

  const handleMatchEnd = (scoreBlue: number, scoreOrange: number) => {
      setIsPlaying(false);
      // Create a fake simulation result to show the final score in the log view after playing
      setSimulation({
          winner: scoreBlue > scoreOrange ? 'BLUE' : (scoreOrange > scoreBlue ? 'ORANGE' : 'DRAW'),
          finalScoreBlue: scoreBlue,
          finalScoreOrange: scoreOrange,
          events: [],
          analysis: "Live combat session concluded. Telemetry uploaded."
      });
      setCurrentEventIndex(0);
  };

  // Effect to play through events like a ticker (Text Mode)
  useEffect(() => {
    if (simulation && currentEventIndex >= 0 && currentEventIndex < simulation.events.length) {
      const timer = setTimeout(() => {
        setCurrentEventIndex(prev => prev + 1);
      }, 1500); 
      return () => clearTimeout(timer);
    }
  }, [currentEventIndex, simulation]);

  // Auto scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentEventIndex]);

  const getScore = () => {
    if (simulation) {
        if (currentEventIndex >= simulation.events.length) {
            return { blue: simulation.finalScoreBlue, orange: simulation.finalScoreOrange };
        }
        if (currentEventIndex >= 0) {
             return {
                blue: simulation.events[currentEventIndex].scoreBlue,
                orange: simulation.events[currentEventIndex].scoreOrange
            };
        }
    }
    return { blue: 0, orange: 0 };
  };

  const scores = getScore();

  return (
    <div className="h-full flex flex-col max-w-6xl mx-auto">
      {/* Scoreboard - Only show if NOT playing (GameArena has its own HUD) */}
      {!isPlaying && (
        <div className="flex items-center justify-between bg-gradient-to-r from-hell-dark via-[#300] to-hell-dark border-b-4 border-hell-red p-6 rounded-t-xl shadow-[0_0_30px_rgba(255,69,0,0.3)]">
            <div className="flex flex-col items-center w-1/3">
                <div className="text-neon-blue text-4xl font-black drop-shadow-[0_0_10px_rgba(0,243,255,0.8)]">{scores.blue}</div>
                <div className="text-xs uppercase tracking-widest text-gray-400">Challengers</div>
            </div>
            
            <div className="w-1/3 flex flex-col items-center">
                <div className="bg-black px-4 py-2 rounded text-hell-orange font-mono text-xl border border-hell-orange animate-pulse-fast shadow-[0_0_15px_rgba(255,69,0,0.5)]">
                    {isSimulating ? 'AI SIMULATION...' : (simulation ? 'POST MATCH' : 'INFERNO DOME')}
                </div>
                <div className="text-hell-text text-[10px] mt-2 font-mono uppercase tracking-[0.2em]">Temperature: CRITICAL</div>
            </div>

            <div className="flex flex-col items-center w-1/3">
                <div className="text-hell-red text-4xl font-black drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">{scores.orange}</div>
                <div className="text-xs uppercase tracking-widest text-gray-400">Abyssal Lords</div>
            </div>
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        
        {/* Squad Selection Panel - Disable while playing */}
        <div className={`bg-ash border border-hell-red/30 rounded-xl p-4 flex flex-col ${isPlaying ? 'opacity-50 pointer-events-none' : ''}`}>
            <h3 className="text-hell-orange uppercase text-sm font-bold mb-4 border-b border-hell-red/30 pb-2 flex justify-between">
                <span>Squad Selection</span>
                <span className={selectedTeam.length === 3 ? "text-green-400" : "text-yellow-400"}>
                    {selectedTeam.length}/3 READY
                </span>
            </h3>
            
            <div className="flex-1 overflow-y-auto pr-2 space-y-2 max-h-[500px]">
                {roster.map(car => {
                    const isSelected = selectedCarIds.has(car.id);
                    // Check if it's the player car (first selected)
                    const isPlayerOne = selectedTeam.length > 0 && selectedTeam[0].id === car.id;

                    return (
                        <div 
                            key={car.id} 
                            onClick={() => toggleCarSelection(car.id)}
                            className={`p-3 rounded border cursor-pointer transition-all ${
                                isSelected 
                                ? 'bg-hell-red/20 border-hell-red shadow-[0_0_10px_rgba(255,0,0,0.2)]' 
                                : 'bg-gray-900/50 border-gray-800 hover:border-gray-600'
                            }`}
                        >
                            <div className="flex items-center justify-between">
                                <div className="font-bold text-sm text-white">{car.name}</div>
                                {isSelected && <div className="w-2 h-2 bg-neon-blue rounded-full shadow-[0_0_5px_#00f3ff]"></div>}
                            </div>
                            <div className="flex justify-between items-center mt-1">
                                <span className="text-xs text-gray-500">{car.class}</span>
                                {isPlayerOne && isSelected && <span className="text-[10px] bg-neon-blue text-black px-1 rounded font-bold">YOU</span>}
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="mt-4 space-y-2">
                 <button 
                    onClick={enterArena}
                    disabled={selectedTeam.length === 0 || isSimulating}
                    className={`w-full py-4 font-black uppercase tracking-widest rounded transition-all duration-300 ${
                        selectedTeam.length === 0 || isSimulating
                        ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                        : 'bg-gradient-to-r from-hell-red to-magma text-white hover:shadow-[0_0_20px_rgba(255,0,0,0.6)] hover:scale-[1.02]'
                    }`}
                >
                    PLAY MATCH
                </button>
                <button 
                    onClick={runSimulation}
                    disabled={selectedTeam.length === 0 || isSimulating}
                    className="w-full py-2 text-xs font-bold uppercase tracking-wider text-gray-500 hover:text-white border border-gray-800 hover:border-gray-600 rounded"
                >
                    Simulate Only (AI)
                </button>
            </div>
        </div>

        {/* Main View: Either the Game Canvas or the Simulation Logs */}
        <div className="lg:col-span-2 flex items-center justify-center">
             {isPlaying ? (
                 <GameArena userSquad={selectedTeam} onMatchEnd={handleMatchEnd} />
             ) : (
                 <div className="w-full h-full bg-black border border-hell-red/50 rounded-xl p-6 overflow-hidden flex flex-col relative shadow-inner min-h-[500px]">
                    {/* Lava Glow Effect */}
                    <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-hell-red/10 to-transparent pointer-events-none"></div>
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-hell-orange to-transparent opacity-80"></div>
                    
                    <div className="flex-1 overflow-y-auto space-y-3 pr-2 font-mono text-sm h-[500px] relative z-10">
                        {simulation && simulation.events.map((event, idx) => {
                            if (idx > currentEventIndex) return null;
                            return (
                                <div 
                                    key={idx} 
                                    className={`p-3 rounded border-l-2 backdrop-blur-sm animate-in fade-in slide-in-from-bottom-2 duration-500 ${
                                        event.type === 'GOAL' ? 'bg-neon-green/10 border-neon-green shadow-[inset_0_0_10px_rgba(0,255,0,0.1)]' :
                                        event.type === 'DEMOLITION' ? 'bg-red-900/40 border-red-500 shadow-[inset_0_0_10px_rgba(255,0,0,0.2)]' :
                                        event.team === 'BLUE' ? 'bg-blue-900/20 border-blue-500' :
                                        event.team === 'ORANGE' ? 'bg-orange-900/20 border-orange-500' :
                                        'bg-gray-900/60 border-gray-700'
                                    }`}
                                >
                                    <div className="flex justify-between text-xs opacity-70 mb-1">
                                        <span className="text-gray-400">{event.timestamp}</span>
                                        <span className={`font-bold ${event.type === 'DEMOLITION' ? 'text-red-500' : 'text-gray-300'}`}>{event.type}</span>
                                    </div>
                                    <p className="text-gray-200">{event.description}</p>
                                </div>
                            );
                        })}
                        {!simulation && !isSimulating && (
                            <div className="h-full flex flex-col items-center justify-center text-gray-600 space-y-4">
                                <div className="text-6xl opacity-20 animate-pulse">🔥</div>
                                <div className="text-sm uppercase tracking-widest">Select Squad & Press Play</div>
                            </div>
                        )}
                        <div ref={logsEndRef} />
                    </div>

                    {/* Analysis box when done */}
                    {simulation && (currentEventIndex >= simulation.events.length || simulation.events.length === 0) && simulation.analysis && (
                        <div className="mt-4 p-4 bg-hell-dark/80 border-t border-hell-red text-sm text-hell-text italic rounded relative z-10">
                            <strong className="text-hell-orange not-italic block mb-1 uppercase tracking-wider">Battle Report:</strong>
                            {simulation.analysis}
                        </div>
                    )}
                 </div>
             )}
        </div>
      </div>
    </div>
  );
};
