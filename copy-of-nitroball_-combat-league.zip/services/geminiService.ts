import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Car, CarClass, MatchSimulationResult, CLASS_INFO } from "../types";

// Ensure API key is available
const apiKey = process.env.API_KEY || '';

// Initialize client only when needed to ensure key freshness if applicable
const getAiClient = () => new GoogleGenAI({ apiKey });

const carSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    stats: {
      type: Type.OBJECT,
      properties: {
        speed: { type: Type.NUMBER, description: "Value between 1-100" },
        handling: { type: Type.NUMBER, description: "Value between 1-100" },
        armor: { type: Type.NUMBER, description: "Value between 1-100" },
        firepower: { type: Type.NUMBER, description: "Value between 1-100" },
      },
      required: ["speed", "handling", "armor", "firepower"],
    },
    specialAbility: { type: Type.STRING, description: "A unique ultimate move name" },
    description: { type: Type.STRING, description: "Short lore description of the vehicle" },
    weaponType: { type: Type.STRING, description: "e.g., Gatling Gun, Plasma Cannon, EMP" },
    color: { type: Type.STRING, description: "A hex color code matching the theme" }
  },
  required: ["name", "stats", "specialAbility", "description", "weaponType", "color"]
};

export const generateCarDesign = async (carClass: CarClass, promptModifier: string): Promise<Partial<Car>> => {
  const ai = getAiClient();
  const classInfo = CLASS_INFO[carClass];
  
  const prompt = `Design a futuristic combat soccer vehicle. 
  Class: ${carClass}.
  Class Description: ${classInfo.description}
  Target Stats (Guide): Speed ${classInfo.stats.speed}, Handling ${classInfo.stats.handling}, Armor ${classInfo.stats.armor}, Firepower ${classInfo.stats.firepower}.
  Style/Theme: ${promptModifier}. 
  
  The game is "NitroBall" (Rocket League with guns).
  - Striker: Fast, agile, ball scorer.
  - Juggernaut: Tank, defender, rammer.
  - Specialist: Tech, ranged support, balanced.

  Return a JSON object with stats adjusted based on the theme but adhering to class archetypes.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: carSchema,
        temperature: 0.8
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    const data = JSON.parse(text);
    return {
      ...data,
      class: carClass,
      id: crypto.randomUUID(),
    };
  } catch (error) {
    console.error("Error generating car:", error);
    throw error;
  }
};

const matchEventSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    timestamp: { type: Type.STRING },
    description: { type: Type.STRING },
    type: { type: Type.STRING, enum: ['GOAL', 'DEMOLITION', 'SAVE', 'SHOT', 'INFO'] },
    team: { type: Type.STRING, enum: ['BLUE', 'ORANGE', 'NEUTRAL'] },
    scoreBlue: { type: Type.INTEGER },
    scoreOrange: { type: Type.INTEGER }
  },
  required: ["timestamp", "description", "type", "team", "scoreBlue", "scoreOrange"]
};

const matchSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    winner: { type: Type.STRING, enum: ['BLUE', 'ORANGE', 'DRAW'] },
    finalScoreBlue: { type: Type.INTEGER },
    finalScoreOrange: { type: Type.INTEGER },
    events: {
      type: Type.ARRAY,
      items: matchEventSchema
    },
    analysis: { type: Type.STRING }
  },
  required: ["winner", "finalScoreBlue", "finalScoreOrange", "events", "analysis"]
};

export const simulateMatch = async (playerTeam: Car[]): Promise<MatchSimulationResult> => {
  const ai = getAiClient();
  
  const teamSummary = playerTeam.map(c => `${c.name} (${c.class}) - Weapon: ${c.weaponType}`).join(', ');
  
  const prompt = `Simulate a high-octane 3-minute match of 'NitroBall' (Combat Soccer).
  
  Arena: THE INFERNO DOME. A deadly hellscape with searing heat and magma hazards.
  Ball: "Neo-Sphere V9" - A premium, perfectly balanced titanium-core sphere. It is incredibly responsive and satisfying to hit, glowing white-hot against the dark arena.

  Player Team (Blue): ${teamSummary}
  Opponent Team (Orange): Abyssal Lords (Demonic AI Team).
  
  Rules: 
  1. Cars can shoot to disable opponents (Demolition).
  2. Cars hit the giant ball to score goals. The ball physics are perfect.
  3. Strikers are fast, Juggernauts block paths, Specialists use tech.
  4. The environment is hostile, but the cars are robust and dedicated to winning.
  
  Generate a play-by-play log of significant events. Ensure the score evolves logically based on team composition.
  Around 5-8 key events.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: matchSchema,
        temperature: 0.9 // Higher temp for chaotic hell matches
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as MatchSimulationResult;
  } catch (error) {
    console.error("Error simulating match:", error);
    throw error;
  }
};